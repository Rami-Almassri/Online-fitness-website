function stopLoading() {
    const loader = document.getElementById("loader");
    loader.classList.add("opacity-0", "hidden");
}